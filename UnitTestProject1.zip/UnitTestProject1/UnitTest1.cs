﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTestProject1
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1(int h)
        {
            Random r = new Random();
            int x=r.Next(1,10);
            int amount = 45;// this is the betting amount 
            if (x == h)
            {
                Console.WriteLine("Your choose the matching number");
                //This random number will decide whether the player winner or not
            }
            if(x != h)
            {
                // if the user select the wrong one his amount is deducted 
                int y=amount -h;
                Console.WriteLine("Your amount is deducted to due to wrong choice");
                Console.WriteLine("Now the remaining amount is"+ y);


                // by this if the amount is reduced to 0 the player is unable to enter the number
                List<int> amountlist = new List<int>();
                // this list holds the all result in a list to check the last result is 0 or less then 0
                amountlist.Add(y);
                if (amountlist.Last() == 0)
                {
                    Console.WriteLine("You are unable to choose the number");                }
            }
            
        }

    }
    public class important : UnitTest1
    {
        public static void main(String[] args)
        {
            UnitTest1 obj = new UnitTest1();
            Console.WriteLine("Enter the number between 1 t0 10");
            string y = Console.ReadLine();
            obj.TestMethod1(Convert.ToInt32(y));

            ;
        }
    }
}